%% Name: Ishaan Malhotra
%% Roll no. : 1610110152
%% Instructer: Prof. Vijay Chakka
%% Lab 1
%% Aim: To understand the basic graphs and plotting techniques
%%
clc
clear all
close all
%% Part 1

A = [[0 0 1 1];[0 0 1 1];[1 1 0 1];[1 1 1 0]]
figure
plot2DGraph(A)

%% Part 2 
complete = [[0 1 1 1];[1 0 1 1];[1 1 0 1];[1 1 1 0]]
bipartite = [[0 0 0 1 1 1 1];[0 0 0 1 1 1 1];[0 0 0 1 1 1 1];[1 1 1 0 0 0 0];[1 1 1 0 0 0 0];[1 1 1 0 0 0 0];[1 1 1 0 0 0 0]]
regular = [[0 1 1 1];[1 0 1 1];[1 1 0 1];[1 1 1 0]]
star = [[0 1 1 1];[1 0 0 0];[1 0 0 0];[1 0 0 0]]
circular = [[0 1 0 1];[1 0 1 0];[0 1 0 1];[0 0 1 1]]
line = [[0 1 0 0];[1 0 1 0];[0 1 0 1];[0 0 1 0]]

figure
plot2DGraph(complete)
figure
plot2DGraph(bipartite)
figure
plot2DGraph(regular)
figure
plot2DGraph(star)
figure
plot2DGraph(circular)
figure
plot2DGraph(line)
